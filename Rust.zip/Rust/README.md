```
docker build -t rustapp .
docker run -it -d --name rustApp -p 8000:8000 rustapp
```